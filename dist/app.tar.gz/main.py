import cv2
import flet as ft

global path
path = ''

def main(page: ft.Page):
    page.title = "Convector"
    page.theme_mode = 'dark'

    def pick_result(e: ft.FilePickerResultEvent):
        global path
        if not e.files:
            selected_files.value = "Ничего не выбрано"
        else:
            selected_files.value = ''
            for el in e.files:
                path += el.path

    pick_dialog = ft.FilePicker(on_result=pick_result)
    page.overlay.append(pick_dialog)
    selected_files = ft.Text()

    zzz = ft.TextField(value='Название файла', width=150)

    def convert(e):
        png_img = cv2.imread(path)
        cv2.imwrite(zzz.value, png_img, [int(cv2.IMWRITE_JPEG_QUALITY), 100])

        img = ft.Image(
            src=zzz.value,
            width=100,
            height=100,
            fit=ft.ImageFit.CONTAIN,
        )

        images = ft.Row(expand=1, wrap=False, scroll="always")
        page.add(img, images)

    page.add(
        ft.Row(
            [
                ft.ElevatedButton(
                    'Выбрать файл',
                    icon=ft.icons.UPLOAD_FILE,
                    on_click=lambda _: pick_dialog.pick_files(allow_multiple=True)
                )
            ]
        ),
        ft.Row(
            [
                zzz,
                ft.TextButton('Convert', on_click=convert)
            ]
        ),
        ft.Row([selected_files])
    )

ft.app(target=main)
